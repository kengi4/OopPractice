﻿namespace OopPractice.Display
{
    public interface IDisplayable
    {
        string Render();
    }
}
