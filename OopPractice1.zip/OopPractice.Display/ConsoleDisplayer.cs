﻿using System;

namespace OopPractice.Display
{
    public class ConsoleDisplayer : IDisplayer
    {
        public void Display(string line)
        {
            Console.WriteLine(line);
        }

        public void Display(IDisplayable displayable)
        {
            Console.WriteLine(displayable.Render());
        }
    }
}