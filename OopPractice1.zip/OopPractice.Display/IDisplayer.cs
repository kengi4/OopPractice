﻿namespace OopPractice.Display
{
    public interface IDisplayer
    {
        void Display(string line);

        void Display(IDisplayable displayable);
    }
}